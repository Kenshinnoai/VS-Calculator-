#pragma once

namespace GoretskiyCalculatorApp {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// ������ ��� MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ exit_button;
	protected:

	private: System::Windows::Forms::Button^ equals_button;






	private: System::Windows::Forms::Button^ plus_button;

	private: System::Windows::Forms::Button^ minus_button;

	private: System::Windows::Forms::Button^ mult_button;

	private: System::Windows::Forms::Button^ div_dutton;
	private: System::Windows::Forms::Button^ dot_button;


	private: System::Windows::Forms::Button^ button13;
	private: System::Windows::Forms::Button^ button14;
	private: System::Windows::Forms::Button^ button15;
	private: System::Windows::Forms::Button^ procent_button;

	private: System::Windows::Forms::Button^ button17;
	private: System::Windows::Forms::Button^ button18;
	private: System::Windows::Forms::Button^ button19;
	private: System::Windows::Forms::Button^ button20;
	private: System::Windows::Forms::Button^ pl_min_button;


	private: System::Windows::Forms::Button^ button23;
	private: System::Windows::Forms::Button^ button24;
	private: System::Windows::Forms::Button^ button25;
	private: System::Windows::Forms::Button^ button_AC;

	private: System::Windows::Forms::Label^ label_res;

	private: float first_num;
	private: char user_action = ' ';
	private: bool is_equals = 0;
	protected:

	private:
		/// <summary>
		/// ������������ ���������� ������������.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// ��������� ����� ��� ��������� ������������ � �� ��������� 
		/// ���������� ����� ������ � ������� ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			this->exit_button = (gcnew System::Windows::Forms::Button());
			this->equals_button = (gcnew System::Windows::Forms::Button());
			this->plus_button = (gcnew System::Windows::Forms::Button());
			this->minus_button = (gcnew System::Windows::Forms::Button());
			this->mult_button = (gcnew System::Windows::Forms::Button());
			this->div_dutton = (gcnew System::Windows::Forms::Button());
			this->dot_button = (gcnew System::Windows::Forms::Button());
			this->button13 = (gcnew System::Windows::Forms::Button());
			this->button14 = (gcnew System::Windows::Forms::Button());
			this->button15 = (gcnew System::Windows::Forms::Button());
			this->procent_button = (gcnew System::Windows::Forms::Button());
			this->button17 = (gcnew System::Windows::Forms::Button());
			this->button18 = (gcnew System::Windows::Forms::Button());
			this->button19 = (gcnew System::Windows::Forms::Button());
			this->button20 = (gcnew System::Windows::Forms::Button());
			this->pl_min_button = (gcnew System::Windows::Forms::Button());
			this->button23 = (gcnew System::Windows::Forms::Button());
			this->button24 = (gcnew System::Windows::Forms::Button());
			this->button25 = (gcnew System::Windows::Forms::Button());
			this->button_AC = (gcnew System::Windows::Forms::Button());
			this->label_res = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// exit_button
			// 
			this->exit_button->BackColor = System::Drawing::Color::White;
			this->exit_button->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->exit_button->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->exit_button->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(40)), static_cast<System::Int32>(static_cast<System::Byte>(42)),
				static_cast<System::Int32>(static_cast<System::Byte>(29)));
			this->exit_button->Location = System::Drawing::Point(523, 12);
			this->exit_button->Name = L"exit_button";
			this->exit_button->Size = System::Drawing::Size(35, 36);
			this->exit_button->TabIndex = 0;
			this->exit_button->Text = L"X";
			this->exit_button->UseVisualStyleBackColor = false;
			this->exit_button->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// equals_button
			// 
			this->equals_button->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(242)), static_cast<System::Int32>(static_cast<System::Byte>(118)),
				static_cast<System::Int32>(static_cast<System::Byte>(108)));
			this->equals_button->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->equals_button->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 36, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->equals_button->ForeColor = System::Drawing::Color::White;
			this->equals_button->Location = System::Drawing::Point(307, 525);
			this->equals_button->Name = L"equals_button";
			this->equals_button->Size = System::Drawing::Size(216, 79);
			this->equals_button->TabIndex = 10;
			this->equals_button->Text = L"=";
			this->equals_button->UseVisualStyleBackColor = false;
			this->equals_button->Click += gcnew System::EventHandler(this, &MyForm::equals_button_Click);
			// 
			// plus_button
			// 
			this->plus_button->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(112)),
				static_cast<System::Int32>(static_cast<System::Byte>(125)));
			this->plus_button->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->plus_button->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 21.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->plus_button->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(254)), static_cast<System::Int32>(static_cast<System::Byte>(181)),
				static_cast<System::Int32>(static_cast<System::Byte>(126)));
			this->plus_button->Location = System::Drawing::Point(435, 435);
			this->plus_button->Name = L"plus_button";
			this->plus_button->Size = System::Drawing::Size(88, 79);
			this->plus_button->TabIndex = 9;
			this->plus_button->Text = L"+";
			this->plus_button->UseVisualStyleBackColor = false;
			this->plus_button->Click += gcnew System::EventHandler(this, &MyForm::plus_button_Click);
			// 
			// minus_button
			// 
			this->minus_button->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(112)),
				static_cast<System::Int32>(static_cast<System::Byte>(125)));
			this->minus_button->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->minus_button->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 21.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->minus_button->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(254)), static_cast<System::Int32>(static_cast<System::Byte>(181)),
				static_cast<System::Int32>(static_cast<System::Byte>(126)));
			this->minus_button->Location = System::Drawing::Point(435, 343);
			this->minus_button->Name = L"minus_button";
			this->minus_button->Size = System::Drawing::Size(88, 79);
			this->minus_button->TabIndex = 8;
			this->minus_button->Text = L"-";
			this->minus_button->UseVisualStyleBackColor = false;
			this->minus_button->Click += gcnew System::EventHandler(this, &MyForm::minus_button_Click);
			// 
			// mult_button
			// 
			this->mult_button->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(112)),
				static_cast<System::Int32>(static_cast<System::Byte>(125)));
			this->mult_button->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->mult_button->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 21.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->mult_button->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(254)), static_cast<System::Int32>(static_cast<System::Byte>(181)),
				static_cast<System::Int32>(static_cast<System::Byte>(126)));
			this->mult_button->Location = System::Drawing::Point(435, 253);
			this->mult_button->Name = L"mult_button";
			this->mult_button->Size = System::Drawing::Size(88, 79);
			this->mult_button->TabIndex = 7;
			this->mult_button->Text = L"*";
			this->mult_button->UseVisualStyleBackColor = false;
			this->mult_button->Click += gcnew System::EventHandler(this, &MyForm::mult_button_Click);
			// 
			// div_dutton
			// 
			this->div_dutton->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(112)),
				static_cast<System::Int32>(static_cast<System::Byte>(125)));
			this->div_dutton->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->div_dutton->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 21.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->div_dutton->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(254)), static_cast<System::Int32>(static_cast<System::Byte>(181)),
				static_cast<System::Int32>(static_cast<System::Byte>(126)));
			this->div_dutton->Location = System::Drawing::Point(435, 166);
			this->div_dutton->Name = L"div_dutton";
			this->div_dutton->Size = System::Drawing::Size(88, 79);
			this->div_dutton->TabIndex = 6;
			this->div_dutton->Text = L"/";
			this->div_dutton->UseVisualStyleBackColor = false;
			this->div_dutton->Click += gcnew System::EventHandler(this, &MyForm::div_dutton_Click);
			// 
			// dot_button
			// 
			this->dot_button->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(112)),
				static_cast<System::Int32>(static_cast<System::Byte>(125)));
			this->dot_button->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->dot_button->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 21.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->dot_button->ForeColor = System::Drawing::Color::White;
			this->dot_button->Location = System::Drawing::Point(44, 525);
			this->dot_button->Name = L"dot_button";
			this->dot_button->Size = System::Drawing::Size(91, 78);
			this->dot_button->TabIndex = 15;
			this->dot_button->Text = L".";
			this->dot_button->UseVisualStyleBackColor = false;
			this->dot_button->Click += gcnew System::EventHandler(this, &MyForm::dot_button_Click);
			// 
			// button13
			// 
			this->button13->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(112)),
				static_cast<System::Int32>(static_cast<System::Byte>(125)));
			this->button13->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->button13->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 21.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->button13->ForeColor = System::Drawing::Color::White;
			this->button13->Location = System::Drawing::Point(307, 435);
			this->button13->Name = L"button13";
			this->button13->Size = System::Drawing::Size(88, 79);
			this->button13->TabIndex = 14;
			this->button13->Text = L"3";
			this->button13->UseVisualStyleBackColor = false;
			this->button13->Click += gcnew System::EventHandler(this, &MyForm::button_num_Click);
			// 
			// button14
			// 
			this->button14->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(112)),
				static_cast<System::Int32>(static_cast<System::Byte>(125)));
			this->button14->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->button14->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 21.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->button14->ForeColor = System::Drawing::Color::White;
			this->button14->Location = System::Drawing::Point(307, 343);
			this->button14->Name = L"button14";
			this->button14->Size = System::Drawing::Size(88, 79);
			this->button14->TabIndex = 13;
			this->button14->Text = L"6";
			this->button14->UseVisualStyleBackColor = false;
			this->button14->Click += gcnew System::EventHandler(this, &MyForm::button_num_Click);
			// 
			// button15
			// 
			this->button15->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(112)),
				static_cast<System::Int32>(static_cast<System::Byte>(125)));
			this->button15->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->button15->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 21.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->button15->ForeColor = System::Drawing::Color::White;
			this->button15->Location = System::Drawing::Point(307, 253);
			this->button15->Name = L"button15";
			this->button15->Size = System::Drawing::Size(88, 79);
			this->button15->TabIndex = 12;
			this->button15->Text = L"9";
			this->button15->UseVisualStyleBackColor = false;
			this->button15->Click += gcnew System::EventHandler(this, &MyForm::button_num_Click);
			// 
			// procent_button
			// 
			this->procent_button->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(112)),
				static_cast<System::Int32>(static_cast<System::Byte>(125)));
			this->procent_button->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->procent_button->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 21.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->procent_button->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(254)), static_cast<System::Int32>(static_cast<System::Byte>(181)),
				static_cast<System::Int32>(static_cast<System::Byte>(126)));
			this->procent_button->Location = System::Drawing::Point(307, 166);
			this->procent_button->Name = L"procent_button";
			this->procent_button->Size = System::Drawing::Size(88, 79);
			this->procent_button->TabIndex = 11;
			this->procent_button->Text = L"%";
			this->procent_button->UseVisualStyleBackColor = false;
			this->procent_button->Click += gcnew System::EventHandler(this, &MyForm::procent_button_Click);
			// 
			// button17
			// 
			this->button17->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(112)),
				static_cast<System::Int32>(static_cast<System::Byte>(125)));
			this->button17->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->button17->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 21.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->button17->ForeColor = System::Drawing::Color::White;
			this->button17->Location = System::Drawing::Point(176, 525);
			this->button17->Name = L"button17";
			this->button17->Size = System::Drawing::Size(91, 78);
			this->button17->TabIndex = 20;
			this->button17->Text = L"0";
			this->button17->UseVisualStyleBackColor = false;
			this->button17->Click += gcnew System::EventHandler(this, &MyForm::button_num_Click);
			// 
			// button18
			// 
			this->button18->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(112)),
				static_cast<System::Int32>(static_cast<System::Byte>(125)));
			this->button18->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->button18->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 21.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->button18->ForeColor = System::Drawing::Color::White;
			this->button18->Location = System::Drawing::Point(176, 435);
			this->button18->Name = L"button18";
			this->button18->Size = System::Drawing::Size(91, 78);
			this->button18->TabIndex = 19;
			this->button18->Text = L"2";
			this->button18->UseVisualStyleBackColor = false;
			this->button18->Click += gcnew System::EventHandler(this, &MyForm::button_num_Click);
			// 
			// button19
			// 
			this->button19->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(112)),
				static_cast<System::Int32>(static_cast<System::Byte>(125)));
			this->button19->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->button19->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 21.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->button19->ForeColor = System::Drawing::Color::White;
			this->button19->Location = System::Drawing::Point(176, 343);
			this->button19->Name = L"button19";
			this->button19->Size = System::Drawing::Size(91, 78);
			this->button19->TabIndex = 18;
			this->button19->Text = L"5";
			this->button19->UseVisualStyleBackColor = false;
			this->button19->Click += gcnew System::EventHandler(this, &MyForm::button_num_Click);
			// 
			// button20
			// 
			this->button20->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(112)),
				static_cast<System::Int32>(static_cast<System::Byte>(125)));
			this->button20->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->button20->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 21.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->button20->ForeColor = System::Drawing::Color::White;
			this->button20->Location = System::Drawing::Point(176, 253);
			this->button20->Name = L"button20";
			this->button20->Size = System::Drawing::Size(91, 78);
			this->button20->TabIndex = 17;
			this->button20->Text = L"8";
			this->button20->UseVisualStyleBackColor = false;
			this->button20->Click += gcnew System::EventHandler(this, &MyForm::button_num_Click);
			// 
			// pl_min_button
			// 
			this->pl_min_button->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(112)),
				static_cast<System::Int32>(static_cast<System::Byte>(125)));
			this->pl_min_button->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->pl_min_button->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 21.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->pl_min_button->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(254)), static_cast<System::Int32>(static_cast<System::Byte>(181)),
				static_cast<System::Int32>(static_cast<System::Byte>(126)));
			this->pl_min_button->Location = System::Drawing::Point(176, 166);
			this->pl_min_button->Name = L"pl_min_button";
			this->pl_min_button->Size = System::Drawing::Size(91, 78);
			this->pl_min_button->TabIndex = 16;
			this->pl_min_button->Text = L"+/-";
			this->pl_min_button->UseVisualStyleBackColor = false;
			this->pl_min_button->Click += gcnew System::EventHandler(this, &MyForm::pl_min_button_Click);
			// 
			// button23
			// 
			this->button23->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(112)),
				static_cast<System::Int32>(static_cast<System::Byte>(125)));
			this->button23->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->button23->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 21.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->button23->ForeColor = System::Drawing::Color::White;
			this->button23->Location = System::Drawing::Point(44, 435);
			this->button23->Name = L"button23";
			this->button23->Size = System::Drawing::Size(91, 78);
			this->button23->TabIndex = 24;
			this->button23->Text = L"1";
			this->button23->UseVisualStyleBackColor = false;
			this->button23->Click += gcnew System::EventHandler(this, &MyForm::button_num_Click);
			// 
			// button24
			// 
			this->button24->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(112)),
				static_cast<System::Int32>(static_cast<System::Byte>(125)));
			this->button24->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->button24->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 21.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->button24->ForeColor = System::Drawing::Color::White;
			this->button24->Location = System::Drawing::Point(44, 343);
			this->button24->Name = L"button24";
			this->button24->Size = System::Drawing::Size(91, 78);
			this->button24->TabIndex = 23;
			this->button24->Text = L"4";
			this->button24->UseVisualStyleBackColor = false;
			this->button24->Click += gcnew System::EventHandler(this, &MyForm::button_num_Click);
			// 
			// button25
			// 
			this->button25->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(112)),
				static_cast<System::Int32>(static_cast<System::Byte>(125)));
			this->button25->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->button25->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 21.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->button25->ForeColor = System::Drawing::Color::White;
			this->button25->Location = System::Drawing::Point(44, 253);
			this->button25->Name = L"button25";
			this->button25->Size = System::Drawing::Size(91, 78);
			this->button25->TabIndex = 22;
			this->button25->Text = L"7";
			this->button25->UseVisualStyleBackColor = false;
			this->button25->Click += gcnew System::EventHandler(this, &MyForm::button_num_Click);
			// 
			// button_AC
			// 
			this->button_AC->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(112)),
				static_cast<System::Int32>(static_cast<System::Byte>(125)));
			this->button_AC->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->button_AC->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 21.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->button_AC->ForeColor = System::Drawing::Color::Firebrick;
			this->button_AC->Location = System::Drawing::Point(44, 166);
			this->button_AC->Name = L"button_AC";
			this->button_AC->Size = System::Drawing::Size(91, 78);
			this->button_AC->TabIndex = 21;
			this->button_AC->Text = L"AC";
			this->button_AC->UseVisualStyleBackColor = false;
			this->button_AC->Click += gcnew System::EventHandler(this, &MyForm::button_AC_Click);
			// 
			// label_res
			// 
			this->label_res->BackColor = System::Drawing::Color::White;
			this->label_res->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->label_res->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 36, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label_res->ForeColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->label_res->ImageAlign = System::Drawing::ContentAlignment::TopCenter;
			this->label_res->Location = System::Drawing::Point(44, 60);
			this->label_res->Name = L"label_res";
			this->label_res->Size = System::Drawing::Size(479, 72);
			this->label_res->TabIndex = 26;
			this->label_res->Text = L"0";
			this->label_res->TextAlign = System::Drawing::ContentAlignment::BottomRight;
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(7, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(251)), static_cast<System::Int32>(static_cast<System::Byte>(184)),
				static_cast<System::Int32>(static_cast<System::Byte>(193)));
			this->ClientSize = System::Drawing::Size(570, 622);
			this->Controls->Add(this->exit_button);
			this->Controls->Add(this->button23);
			this->Controls->Add(this->button24);
			this->Controls->Add(this->button25);
			this->Controls->Add(this->button_AC);
			this->Controls->Add(this->button17);
			this->Controls->Add(this->button18);
			this->Controls->Add(this->button19);
			this->Controls->Add(this->button20);
			this->Controls->Add(this->pl_min_button);
			this->Controls->Add(this->dot_button);
			this->Controls->Add(this->button13);
			this->Controls->Add(this->button14);
			this->Controls->Add(this->button15);
			this->Controls->Add(this->procent_button);
			this->Controls->Add(this->equals_button);
			this->Controls->Add(this->plus_button);
			this->Controls->Add(this->minus_button);
			this->Controls->Add(this->mult_button);
			this->Controls->Add(this->div_dutton);
			this->Controls->Add(this->label_res);
			this->Cursor = System::Windows::Forms::Cursors::Default;
			this->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->ForeColor = System::Drawing::SystemColors::AppWorkspace;
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::None;
			this->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->Name = L"MyForm";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"MyForm";
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e)
	{
		Close();
	}

	private: System::Void button_num_Click(System::Object^ sender, System::EventArgs^ e)
	{
		Button^ button = safe_cast<Button^>(sender);

		if (this->label_res->Text == "0" || is_equals)
		{
			this->label_res->Text = button->Text;
		}
		else
		{
			this->label_res->Text += button->Text;
		}
	}

	private: System::Void action(char act)
	{
		this->first_num = System::Convert::ToDouble(this->label_res->Text);

		this->user_action = act;

		this->label_res->Text = "0";
	}


	private: System::Void div_dutton_Click(System::Object^ sender, System::EventArgs^ e)
	{
		action('/');
	}
	private: System::Void mult_button_Click(System::Object^ sender, System::EventArgs^ e)
	{
		action('*');
	}
	private: System::Void minus_button_Click(System::Object^ sender, System::EventArgs^ e)
	{
		action('-');
	}
	private: System::Void plus_button_Click(System::Object^ sender, System::EventArgs^ e)
	{
		action('+');
	}
	private: System::Void equals_button_Click(System::Object^ sender, System::EventArgs^ e)
	{
		if (this->user_action == ' ')
		{
			return;
		}
		float second_num = System::Convert::ToDouble(this->label_res->Text);
		float res = 0;

		switch (this->user_action)
		{
		case '+':
			res = this->first_num + second_num;
			break;

		case '-':
			res = this->first_num - second_num;
			break;

		case '*':
			res = this->first_num * second_num;
			break;

		case '/':
			if (second_num == 0)
			{
				res = 0;
				MessageBox::Show("Can't divide by zero", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
			}
			else
			{
				res = this->first_num / second_num;
			}
			break;
		}
		is_equals = 1;
		this->label_res->Text = System::Convert::ToString(res);


	}
	private: System::Void button_AC_Click(System::Object^ sender, System::EventArgs^ e)
	{
		this->label_res->Text = "0";
		is_equals = 0;
		this->user_action = ' ';
		first_num = 0;
	}

	private: System::Void pl_min_button_Click(System::Object^ sender, System::EventArgs^ e)
	{
		this->label_res->Text = System::Convert::ToString(-(System::Convert::ToDouble(this->label_res->Text)));
	}

	private: System::Void procent_button_Click(System::Object^ sender, System::EventArgs^ e)
	{
		this->label_res->Text = System::Convert::ToString(System::Convert::ToDouble(this->label_res->Text) * 0.01);
	}
	private: System::Void dot_button_Click(System::Object^ sender, System::EventArgs^ e)
	{
		if (!this->label_res->Text->Contains("."))
			this->label_res->Text += ",";
	}
	};
}
